package com.example.sakibcse.chatserver;

import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import yuku.ambilwarna.AmbilWarnaDialog;

public class Conversation extends AppCompatActivity implements View.OnClickListener {

    private Handler handler = new Handler();
    private boolean end=false;
    EditText writeMessage;
    ImageButton sendBtn;
    ListView messageList;
    MessageAdapter messageAdapter=new MessageAdapter(this);
    private ServerSocket serverSocket;
    private Socket tempClientSocket;
    Thread serverThread = null;
    public static final int SERVER_PORT = 4004;
    public int initialColor,bgColor;
    public String hexColor;
    private LinearLayout chatbg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation);
        setTitle("Receiver");

        Toolbar toolbar = findViewById(R.id.toolbarID);
        setSupportActionBar(toolbar);

        loadData();

        chatbg = (LinearLayout) findViewById(R.id.ChatBg);
        chatbg.setBackgroundColor(bgColor);

        writeMessage=(EditText) findViewById(R.id.inputMessage);
        sendBtn=(ImageButton) findViewById(R.id.sendButton);
        messageList=(ListView) findViewById(R.id.messages_view);

        writeMessage.setOnClickListener(this);
        sendBtn.setOnClickListener(this);

        messageList.setAdapter(messageAdapter);
        handler = new Handler();

        this.serverThread = new Thread(new ServerThread());
        this.serverThread.start();

    }

    public void showMessage(final String message, final boolean sender) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                messageAdapter.add(new Message(message,sender));
                if(messageAdapter!=null) messageAdapter.notifyDataSetChanged();
                saveMessage();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_layout,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.background){
            openColorPickerDialogue();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void openColorPickerDialogue(){
        AmbilWarnaDialog dialog = new AmbilWarnaDialog(this,initialColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                initialColor=color;
                bgColor=color;
                chatbg.setBackgroundColor(color);
                saveMessage();
            }
        });
        dialog.show();
    }

    private void saveMessage(){
        SharedPreferences sharedPreferences=getSharedPreferences("messageStorageSP",MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(messageAdapter.messages);
        editor.putString("messageList",json);
        editor.putInt("backgroundColor",bgColor);
        editor.apply();
    }

    private void loadData(){
        SharedPreferences sharedPreferences=getSharedPreferences("messageStorageSP",MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("messageList",null);
        Type type = new TypeToken<ArrayList<Message>>() {}.getType();
        messageAdapter.messages = gson.fromJson(json,type);
        bgColor = sharedPreferences.getInt("backgroundColor",bgColor);

        if(messageAdapter.messages == null) {
            messageAdapter.messages = new ArrayList<Message>();
        }

    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.sendButton){
            String messageOUT=writeMessage.getText().toString().trim();

            if(messageOUT!=null && !TextUtils.isEmpty(messageOUT)){
                showMessage(messageOUT,true);
               // Toast.makeText(getApplicationContext(),ip,Toast.LENGTH_LONG).show();
                writeMessage.setText("");
                if (null != serverThread) {
                    sendMessage(messageOUT);
                }
                saveMessage();
            }
        }
    }



    private void sendMessage(final String message) {
        try {
            if (null != tempClientSocket) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        PrintWriter out = null;
                        try {
                            out = new PrintWriter(new BufferedWriter(
                                    new OutputStreamWriter(tempClientSocket.getOutputStream())),
                                    true);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        out.println(message);
                    }
                }).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class ServerThread implements Runnable {

        public void run() {
            Socket socket;
            try {
                serverSocket = new ServerSocket(SERVER_PORT);
                //findViewById(R.id.start_server).setVisibility(View.GONE);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),"Error Connecting to Client",Toast.LENGTH_LONG).show();
            }
            if (null != serverSocket) {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        socket = serverSocket.accept();
                        CommunicationThread commThread = new CommunicationThread(socket);
                        new Thread(commThread).start();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(),"Error Connecting to Client",Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }

    class CommunicationThread implements Runnable {

        private Socket clientSocket;

        private BufferedReader input;

        public CommunicationThread(Socket clientSocket) {
            this.clientSocket = clientSocket;
            tempClientSocket = clientSocket;
            try {
                this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),"Error Connecting to client",Toast.LENGTH_LONG).show();
            }
            Toast.makeText(getApplicationContext(),"Connected to client",Toast.LENGTH_LONG).show();
        }

        public void run() {

            while (!Thread.currentThread().isInterrupted()) {
                try {
                    String read = input.readLine();
                    if (null == read || "Disconnect".contentEquals(read)) {
                        Thread.interrupted();
                        read = "Client Disconnected";
                        Toast.makeText(getApplicationContext(),read,Toast.LENGTH_LONG).show();
                        break;
                    }

                    showMessage(read,false);

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

}


