package com.example.sakibcse.chatbox;

import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import yuku.ambilwarna.AmbilWarnaDialog;

public class Conversation extends AppCompatActivity implements View.OnClickListener {

    String ip;
    public static final int SERVERPORT = 4004;
    private Handler handler = new Handler();
    private boolean end=false;
    EditText writeMessage;
    ImageButton sendBtn;
    ListView messageList;
    MessageAdapter messageAdapter=new MessageAdapter(this);
    private ClientThread clientThread;
    private Thread thread;
    public int initialColor,bgColor;
    private LinearLayout chatbg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation);
        setTitle("Client");

        ip = getIntent().getStringExtra("ip");

        Toolbar toolbar = findViewById(R.id.toolbarID);
        setSupportActionBar(toolbar);


        loadData();

        chatbg=(LinearLayout) findViewById(R.id.Chatbg);

        writeMessage=(EditText) findViewById(R.id.inputMessage);
        sendBtn=(ImageButton) findViewById(R.id.sendButton);
        messageList=(ListView) findViewById(R.id.messages_view);

        writeMessage.setOnClickListener(this);
        sendBtn.setOnClickListener(this);

        messageList.setAdapter(messageAdapter);
        handler = new Handler();

        clientThread = new ClientThread();
        thread = new Thread(clientThread);
        thread.start();

    }

    public void showMessage(final String message, final boolean sender) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                messageAdapter.add(new Message(message,sender));
                if(messageAdapter!=null) messageAdapter.notifyDataSetChanged();
                saveMessage();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_layout,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.background){
            //Toast.makeText(getApplicationContext(),"Message saved",Toast.LENGTH_LONG).show();
            openColorPickerDialogue();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void openColorPickerDialogue(){
        AmbilWarnaDialog dialog = new AmbilWarnaDialog(this,initialColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                initialColor=color;
                chatbg.setBackgroundColor(color);
                bgColor=color;
                String hexColor = String.format("#%06X", (0xFFFFFF & color));
                clientThread.sendMessage(hexColor);
                saveMessage();
                //Toast.makeText(getApplicationContext(),hexColor,Toast.LENGTH_LONG).show();
            }
        });
        dialog.show();
    }


    private void saveMessage(){
        SharedPreferences sharedPreferences=getSharedPreferences("messageStorageSP",MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(messageAdapter.messages);
        editor.putString("messageList",json);
        editor.putInt("backgroundColor",bgColor);
        editor.apply();
    }

    private void loadData(){
        SharedPreferences sharedPreferences=getSharedPreferences("messageStorageSP",MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("messageList",null);
        Type type = new TypeToken<ArrayList<Message>>() {}.getType();
        messageAdapter.messages = gson.fromJson(json,type);
        bgColor = sharedPreferences.getInt("backgroundColor",bgColor);

        if(messageAdapter.messages == null) {
            messageAdapter.messages = new ArrayList<Message>();
        }

    }


    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.sendButton){
            String messageOUT=writeMessage.getText().toString().trim();

            if(messageOUT!=null && !TextUtils.isEmpty(messageOUT)){
                showMessage(messageOUT,true);
                Toast.makeText(getApplicationContext(),ip,Toast.LENGTH_LONG).show();
                writeMessage.setText("");
                if (null != clientThread) {
                    clientThread.sendMessage(messageOUT);
                    saveMessage();
                }
            }
        }
    }



    class ClientThread implements Runnable {

        private Socket socket;
        private BufferedReader input;


        @Override
        public void run() {

            try {
                socket = new Socket(ip, SERVERPORT);

                while (!Thread.currentThread().isInterrupted()) {

                    this.input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String messageIN = input.readLine();
                    if (null == messageIN || "Disconnect".contentEquals(messageIN)) {
                        Thread.interrupted();
                        Toast.makeText(getApplicationContext(),"Server Disconnected",Toast.LENGTH_LONG).show();
                        break;
                    }

                       showMessage(messageIN,false);


                }

            } catch (UnknownHostException e1) {
                Toast.makeText(getApplicationContext(),"UnknownHostException Error",Toast.LENGTH_LONG).show();
               // e1.printStackTrace();
            } catch (IOException e1) {
                Toast.makeText(getApplicationContext(),"IOException Error",Toast.LENGTH_LONG).show();
                //e1.printStackTrace();
            }
        }

        void sendMessage(final String messageOut) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (null != socket) {
                            PrintWriter out = new PrintWriter(new BufferedWriter(
                                    new OutputStreamWriter(socket.getOutputStream())),
                                    true);
                            out.println(messageOut);

                        }
                    } catch (Exception e) {
                       // e.printStackTrace();
                        Toast.makeText(getApplicationContext(),"Server not connected",Toast.LENGTH_LONG).show();
                    }
                }
            }).start();
        }

    }

}

