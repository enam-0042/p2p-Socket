package com.example.sakibcse.chatbox;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Welcome extends AppCompatActivity {

    EditText inputIP;
    Button proceed;
    String recipientIp;

    private static final String ip_pattern = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
            "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
            "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
            "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        inputIP = (EditText) findViewById(R.id.inputIPAddress);
        proceed = (Button) findViewById(R.id.proceedbtn);

        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipientIp = inputIP.getText().toString().trim();

                if(ip_validate(recipientIp)) {
                    Toast.makeText(getApplicationContext(),"Connected to "+recipientIp,Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(),Conversation.class);
                    intent.putExtra("ip",recipientIp);
                    startActivity(intent);
                    Toast.makeText(getApplicationContext(),"Connected ",Toast.LENGTH_LONG).show();

                    finish();
                }
                else{
                    inputIP.setError("invalid ip address");
                    inputIP.requestFocus();
                }
            }
        });

    }

    public static boolean ip_validate(String ip){
        Pattern pattern = Pattern.compile(ip_pattern);
        Matcher matcher = pattern.matcher(ip);

        return matcher.matches();
    }

}
